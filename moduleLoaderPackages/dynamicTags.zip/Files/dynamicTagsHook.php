<?php
    $hook_array['before_save'][] = Array(
        1,
        'Dynamic Tags from Desscription',
        'custom/dynamicTags.php',
        'dynamicTagsClass',
        'dynamicTagsMethod'
    );
?>