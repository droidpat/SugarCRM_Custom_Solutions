<?php
    $hook_array['before_save'][] = Array(
        1,
        'Will default assigned Chris',
        'custom/defaultUser.php',
        'defaultUserClass',
        'defaultUserMethod'
    );
?>