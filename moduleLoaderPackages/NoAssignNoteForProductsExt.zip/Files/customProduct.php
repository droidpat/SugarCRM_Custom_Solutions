<?php

require_once('modules/Products/Product.php');

class CustomProduct extends Product
{
    function send_assignment_notifications($notify_user, $admin) {
    }
}
