<?php

$objectList['Products'] = 'Product';
$beanList['Products'] = 'CustomProduct';
$beanFiles['CustomProduct'] = 'custom/modules/Products/Product.php';